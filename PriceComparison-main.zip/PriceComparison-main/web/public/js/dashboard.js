const productsList = document.getElementById('products-list');
const historyContainer = document.getElementById('history-container');
const emptyMessage = document.getElementById('empty-message');
const searchGtinInput = document.getElementById('search-gtin');
const searchBtn = document.getElementById('search-btn');
const priceTable = document.getElementById('price-tbody');

let currentGtin = null;
let allProducts = [];

async function loadTopProducts() {
    try {
        const res = await fetch('/api/top-products?limit=30&days=30');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        allProducts = data.products || [];
        renderProductsList(allProducts);
    } catch (e) {
        productsList.innerHTML = `<div class="empty-state"><p>Fejl ved indlæsning: ${e.message}</p></div>`;
    }
}

function renderProductsList(products) {
    if (products.length === 0) {
        productsList.innerHTML = `<div class="empty-state" style="padding: 2rem;"><p>Ingen data endnu.<br>Start med at søge på PedalPricer →</p></div>`;
        return;
    }

    productsList.innerHTML = products.map(p => {
        const isActive = currentGtin === p.gtin ? 'active' : '';
        return `
        <div class="product-item ${isActive}" data-gtin="${p.gtin}">
            <div class="product-gtin">${p.gtin}</div>
            <div class="product-meta">${p.name ? p.name.substring(0, 50) : 'Produktnavn ukendt'}</div>
            <div class="product-meta" style="margin-top: 0.5rem; opacity: 0.6;">${p.searches} søgning${p.searches === 1 ? '' : 'er'}</div>
        </div>
    `;
    }).join('');

    document.querySelectorAll('.product-item').forEach(el => {
        el.addEventListener('click', () => loadHistory(el.dataset.gtin));
    });
}

async function loadHistory(gtin) {
    if (!/^\d{8,14}$/.test(gtin)) {
        alert('Ugyldigt GTIN format');
        return;
    }

    currentGtin = gtin;
    renderProductsList(allProducts);

    try {
        const res = await fetch(`/api/history/${gtin}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

        const latest = data.latest || [];
        const history = data.history || [];

        if (latest.length === 0) {
            emptyMessage.style.display = 'flex';
            historyContainer.classList.remove('active');
            return;
        }

        emptyMessage.style.display = 'none';
        historyContainer.classList.add('active');

        document.getElementById('history-title').textContent = gtin;
        document.getElementById('history-meta').textContent = latest.length > 0
            ? `Seneste snapshot: ${new Date(latest[0].crawled_at * 1000).toLocaleDateString('da-DK')}`
            : '';

        document.getElementById('search-link').href = `/?q=${encodeURIComponent(gtin)}`;

        priceTable.innerHTML = latest.map((item, i) => {
            const prevPrice = history.find(h => h.shop === item.shop && h.crawled_at < item.crawled_at)?.price_dkk;
            let changeHtml = '';
            if (prevPrice) {
                const diff = item.price_dkk - prevPrice;
                const pct = ((diff / prevPrice) * 100).toFixed(1);
                const className = diff < 0 ? 'change-down' : 'change-up';
                const sign = diff < 0 ? '' : '+';
                changeHtml = `<div class="change-text ${className}">${sign}${diff} kr (${sign}${pct}%)</div>`;
            } else {
                changeHtml = '<div class="change-text" style="opacity: 0.5;">Første snapshot</div>';
            }
            return `
                <tr>
                    <td>${item.shop}</td>
                    <td><span class="price-badge">${item.price_dkk} kr</span></td>
                    <td>${new Date(item.crawled_at * 1000).toLocaleDateString('da-DK')}</td>
                    <td>${changeHtml}</td>
                </tr>
            `;
        }).join('');

        if (typeof window.umami !== 'undefined') {
            window.umami.track('dashboard-view-history', { gtin, shops: latest.length });
        }
    } catch (e) {
        emptyMessage.style.display = 'flex';
        emptyMessage.innerHTML = `<p>Fejl: ${e.message}</p>`;
        historyContainer.classList.remove('active');
    }
}

searchBtn.addEventListener('click', () => {
    const gtin = searchGtinInput.value.trim();
    if (gtin) {
        loadHistory(gtin);
        if (typeof window.umami !== 'undefined') {
            window.umami.track('dashboard-search', { gtin });
        }
    }
});

searchGtinInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') searchBtn.click();
});

async function loadStats() {
    try {
        const res = await fetch('/api/stats?days=30');
        if (!res.ok) return;
        const data = await res.json();

        const statsRow = document.getElementById('stats-row');
        const shopsEl = document.getElementById('stats-shops');
        const productsEl = document.getElementById('stats-products');

        if (data.topShops.length === 0 && data.topClicked.length === 0) return;

        statsRow.style.display = 'grid';
        const maxClicks = data.topShops[0]?.clicks || 1;

        shopsEl.innerHTML = data.topShops.slice(0, 6).map(s => `
            <div class="stat-bar">
                <div class="stat-bar-label">${s.shop}</div>
                <div class="stat-bar-fill" style="width: ${Math.round((s.clicks / maxClicks) * 80)}px"></div>
                <div class="stat-bar-count">${s.clicks}</div>
            </div>
        `).join('') || '<p style="color:#9ca3af;font-size:0.85rem">Ingen data endnu</p>';

        const maxProductClicks = data.topClicked[0]?.clicks || 1;
        productsEl.innerHTML = data.topClicked.slice(0, 6).map(p => `
            <div class="stat-bar">
                <div class="stat-bar-label">${p.name ? p.name.substring(0, 30) : p.gtin}</div>
                <div class="stat-bar-fill" style="width: ${Math.round((p.clicks / maxProductClicks) * 80)}px"></div>
                <div class="stat-bar-count">${p.clicks}</div>
            </div>
        `).join('') || '<p style="color:#9ca3af;font-size:0.85rem">Ingen data endnu</p>';
    } catch (e) {}
}

loadTopProducts();
loadStats();
if (typeof window.umami !== 'undefined') {
    window.umami.track('page-view-dashboard');
}
