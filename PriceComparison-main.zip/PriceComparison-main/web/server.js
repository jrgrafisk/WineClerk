const express = require('express');
const path = require('path');
const { compareByGTIN } = require('./lib/compare');
const { extractGTINFromURL } = require('./lib/gtinExtract');
const db = require('./lib/db');

const app = express();

// Trust one proxy hop (nginx/Cloudflare) so req.ip is the real client IP
app.set('trust proxy', 1);

app.use(express.json({ limit: '10kb' }));

// Security headers
app.use((req, res, next) => {
    res.setHeader('Content-Security-Policy',
        "default-src 'self'; " +
        "script-src 'self' 'unsafe-inline' https://analytics.jrgrafisk.dk; " +
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
        "font-src https://fonts.gstatic.com; " +
        "img-src 'self' https://jrgrafisk.dk data:; " +
        "media-src https://jrgrafisk.dk; " +
        "connect-src 'self' https://analytics.jrgrafisk.dk;"
    );
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
});

app.use(express.static(path.join(__dirname, 'public')));

// Support + privacy page — also reachable at /support+privacy (add-on store link format)
const supportPage = path.join(__dirname, 'public', 'support.html');
app.get('/support', (req, res) => res.sendFile(supportPage));
app.get('/support+privacy', (req, res) => res.sendFile(supportPage));
app.get('/privacy', (req, res) => res.sendFile(supportPage));

app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));

// CORS — only allow requests from pedalpricer.cc itself
const ALLOWED_ORIGINS = new Set(['https://pedalpricer.cc', 'https://www.pedalpricer.cc']);
function corsCheck(req, res, next) {
    const origin = req.headers.origin;
    if (origin && !ALLOWED_ORIGINS.has(origin)) {
        return res.status(403).json({ error: 'Forbidden' });
    }
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    next();
}

// Simple in-memory rate limiter
const rateLimiter = new Map();
const RATE_WINDOW = 60_000;

setInterval(() => {
    const now = Date.now();
    for (const [ip, entry] of rateLimiter) {
        if (now > entry.resetAt) rateLimiter.delete(ip);
    }
}, 5 * 60_000);

function makeRateLimit(limit) {
    return function rateLimit(req, res, next) {
        const ip = req.ip;
        const now = Date.now();
        const entry = rateLimiter.get(ip) || { count: 0, resetAt: now + RATE_WINDOW };
        if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + RATE_WINDOW; }
        entry.count++;
        rateLimiter.set(ip, entry);
        if (entry.count > limit) {
            return res.status(429).json({ error: 'For mange anmodninger. Prøv igen om lidt.' });
        }
        next();
    };
}

const rateLimit        = makeRateLimit(20);   // compare endpoint
const rateLimitRelaxed = makeRateLimit(120);  // dashboard endpoints

let rssCache = null;
let rssCacheAt = 0;
const RSS_CACHE_TTL = 60 * 60 * 1000;

app.get('/api/rss', rateLimit, async (req, res) => {
    const now = Date.now();
    if (rssCache && now - rssCacheAt < RSS_CACHE_TTL) {
        return res.json(rssCache);
    }
    try {
        const r = await fetch('https://addons.mozilla.org/api/v5/addons/addon/pedalpricer/', {
            headers: { 'User-Agent': 'PedalPricer/1.0 (+https://pedalpricer.cc)' },
            signal: AbortSignal.timeout(5000)
        });
        if (!r.ok) throw new Error(`AMO API ${r.status}`);
        const data = await r.json();
        const version = data.current_version?.version;
        if (!version || !/^\d+[\d.]*$/.test(version)) throw new Error('Unexpected version format');
        rssCache = { version, updated: data.last_updated };
        rssCacheAt = now;
        res.json(rssCache);
    } catch (e) {
        res.status(502).json({ error: 'Kunne ikke hente version' });
    }
});

app.post('/api/compare', corsCheck, rateLimit, async (req, res) => {
    try {
        const { input } = req.body;
        if (!input || !input.trim()) {
            return res.status(400).json({ error: 'Indsæt en produkt-URL eller stregkode.' });
        }

        let gtin = input.trim();

        if (gtin.startsWith('http')) {
            gtin = await extractGTINFromURL(gtin);
            if (!gtin) {
                return res.status(404).json({ error: 'Kunne ikke finde en stregkode på den side. Prøv at indsætte EAN/GTIN direkte.' });
            }
        }

        if (!/^\d{8,14}$/.test(gtin)) {
            return res.status(400).json({ error: 'Ugyldigt format. Indsæt en gyldig EAN/GTIN (8–14 cifre) eller en produkt-URL.' });
        }

        const { results, shopStatus, productName } = await compareByGTIN(gtin);
        db.logSearch(gtin, 'web');
        res.json({ gtin, productName, results, shopStatus });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Der opstod en fejl. Prøv igen.' });
    }
});

// Anonymous click event from extension — IP is never stored
const VALID_SHOP_NAMES = new Set(require('../config.js').SHOPS.map(s => s.name));
app.post('/api/event/click', rateLimitRelaxed, (req, res) => {
    const { gtin, shop, price_dkk } = req.body || {};
    if (!gtin || !/^\d{8,14}$/.test(gtin)) return res.status(400).json({ error: 'Ugyldigt GTIN' });
    if (!shop || !VALID_SHOP_NAMES.has(shop))  return res.status(400).json({ error: 'Ukendt butik' });
    const price = price_dkk != null ? Math.round(Number(price_dkk)) : null;
    db.logClick(gtin, shop, price);
    res.json({ ok: true });
});

app.get('/api/stats', corsCheck, rateLimitRelaxed, (req, res) => {
    const days = Math.min(parseInt(req.query.days ?? 30, 10), 365);
    res.json({
        topShops: db.topShopsByClicks(days),
        topClicked: db.topGtinsByClicks(20, days),
        days
    });
});

app.get('/api/top-products', corsCheck, rateLimitRelaxed, (req, res) => {
    const limit = Math.min(parseInt(req.query.limit ?? 20, 10), 100);
    const days  = Math.min(parseInt(req.query.days ?? 30, 10), 365);
    const products = db.topGtinsWithProducts(limit, days);
    res.json({ products, limit, days });
});

app.get('/api/history/:gtin', corsCheck, rateLimitRelaxed, (req, res) => {
    const { gtin } = req.params;
    if (!/^\d{8,14}$/.test(gtin)) {
        return res.status(400).json({ error: 'Ugyldigt GTIN' });
    }
    const history = db.priceHistory(gtin);
    const latest  = db.latestPrices(gtin);
    res.json({ gtin, latest, history });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`PedalPricer kører på port ${PORT}`));
