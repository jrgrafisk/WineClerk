const Logger = {
    async logClick(data) {
        // Anonymous stats — no IP, no user data stored
        browser.runtime.sendMessage({
            action: "trackClickAnon",
            data: {
                gtin: data.gtin,
                shop: data.store,
                price_dkk: data.dkkPrice ?? null
            }
        });
    }
};

// Make available in both browser and Node.js environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Logger;
} else {
    window.Logger = Logger;
} 